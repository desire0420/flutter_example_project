import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test_demo/live_clear_layer.dart';

import 'live_clear_drawer.dart';

class LiveClearPage extends StatefulWidget {
  const LiveClearPage();

  @override
  State<StatefulWidget> createState() {
    return _LiveClearPageState();
  }
}

class _LiveClearPageState extends State<LiveClearPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      drawerScrimColor: Colors.transparent,
      endDrawerEnableOpenDragGesture: false,
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.transparent,
      endDrawer: LiveClearDrawer(),
      appBar: AppBar(
        title: Text("liveClear"),
        centerTitle: true,
      ),
      body: Stack(
        children: <Widget>[
          Container(color: const Color(0xFFdd3434), width: double.infinity, height: double.infinity),
          LiveClearLayer(
              children: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text("134567"),
                  Text("134567"),
                  Text("134567"),
                  Text("134567"),
                  Text("134567"),
                  Text("134567"),
                  Text("134567"),
                  Text("134567"),
                  Text("134567"),
                  Text("134567")
                ],
              ),
              onLeftListener: () {
                scaffoldKey.currentState?.openEndDrawer();
              })
        ],
      ),
    );
  }
}
