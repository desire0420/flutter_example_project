class AssetUtils {
  static const String guide1 = "assets/images/guide1.png";


}
